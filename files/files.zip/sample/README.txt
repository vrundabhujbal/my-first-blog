This directory contains files used for the example Django application
